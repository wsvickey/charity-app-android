package com.tech.agape4charity.object;

/**
 * Created by Charitha Ratnayake on 6/5/2018.
 */

public class AddToMyListResponseEvent extends AppResponse{
}
