package com.tech.agape4charity.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;

public class TextViewLight extends AppCompatTextView {
    public TextViewLight(Context context, AttributeSet attrs) {
        super(context, attrs);

        setFont(context);
    }

    public void setFont(Context context) {
        Typeface typeface = Typeface.createFromAsset(context.getAssets(),
                "fonts/OpenSans-Regular.ttf");
        this.setTypeface(typeface);
    }
}
